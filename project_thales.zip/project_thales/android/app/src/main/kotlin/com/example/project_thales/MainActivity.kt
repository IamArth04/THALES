package com.example.project_thales

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
