class Tutorial {
  final String title;
  final String description;
  final String imageUrl;

  Tutorial({
    required this.title,
    required this.description,
    required this.imageUrl,
  });
}
