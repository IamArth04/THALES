class Market {
  final String name;
  final String location;
  final double latitude;
  final double longitude;

  Market({
    required this.name,
    required this.location,
    required this.latitude,
    required this.longitude,
  });
}
