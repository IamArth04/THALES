import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../models/market.dart';
import '../widgets/market_card.dart';

class MarketFinderScreen extends StatefulWidget {
  @override
  _MarketFinderScreenState createState() => _MarketFinderScreenState();
}

class _MarketFinderScreenState extends State<MarketFinderScreen> {
  late GoogleMapController mapController;

  final LatLng _center =
      const LatLng(37.7749, -122.4194); // Example: San Francisco

  final List<Market> markets = [
    Market(
      name: 'Downtown Farmers Market',
      location: '123 Main St',
      latitude: 37.7749,
      longitude: -122.4194,
    ),
    Market(
      name: 'Rooftop Organic Market',
      location: '456 Rooftop Ave',
      latitude: 37.7849,
      longitude: -122.4094,
    ),
    // Add more markets as needed
  ];

  Set<Marker> _createMarkers() {
    return markets
        .map(
          (market) => Marker(
            markerId: MarkerId(market.name),
            position: LatLng(market.latitude, market.longitude),
            infoWindow: InfoWindow(
              title: market.name,
              snippet: market.location,
            ),
          ),
        )
        .toSet();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          flex: 2,
          child: GoogleMap(
            onMapCreated: (controller) {
              mapController = controller;
            },
            initialCameraPosition: CameraPosition(
              target: _center,
              zoom: 12.0,
            ),
            markers: _createMarkers(),
          ),
        ),
        Expanded(
          flex: 1,
          child: ListView.builder(
            itemCount: markets.length,
            itemBuilder: (context, index) {
              return MarketCard(market: markets[index]);
            },
          ),
        ),
      ],
    );
  }
}
