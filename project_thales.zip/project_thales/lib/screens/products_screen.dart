import 'package:flutter/material.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';

class ProductsScreen extends StatelessWidget {
  final List<Product> products = [
    Product(
      name: 'Compostable Pots',
      description: 'Eco-friendly pots made from biodegradable materials.',
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Product(
      name: 'Organic Seeds',
      description: 'High-quality organic seeds for various plants.',
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Product(
      name: 'Water-Saving Irrigation System',
      description: 'Efficient irrigation systems to conserve water.',
      imageUrl: 'https://via.placeholder.com/150',
    ),
    // Add more products as needed
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(8.0),
      itemCount: products.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, childAspectRatio: 3 / 4),
      itemBuilder: (context, index) {
        return ProductCard(product: products[index]);
      },
    );
  }
}
