// import 'package:flutter/material.dart';
// import 'package:charts_flutter/flutter.dart' as charts;

// import '../widgets/dashboard_chart.dart';

// class DashboardScreen extends StatelessWidget {
//   final List<charts.Series> seriesList = _createSampleData();

//   static List<charts.Series<ChartData, String>> _createSampleData() {
//     final data = [
//       ChartData('Food Grown', 150),
//       ChartData('Waste Saved', 80),
//       ChartData('Money Saved', 200),
//     ];

//     return [
//       charts.Series<ChartData, String>(
//         id: 'Sustainability',
//         colorFn: (_, __) => charts.MaterialPalette.green.shadeDefault,
//         domainFn: (ChartData data, _) => data.label,
//         measureFn: (ChartData data, _) => data.value,
//         data: data,
//       )
//     ];
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: DashboardChart(
//         seriesList: seriesList,
//         animate: true,
//       ),
//     );
//   }
// }

// class ChartData {
//   final String label;
//   final int value;

//   ChartData(this.label, this.value);
// }

import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:project_thales/widgets/dashboard_chart.dart';
//import 'dashboard_chart.dart'; // Make sure to import the file with DashboardChart and ChartData classes.

class DashboardScreen extends StatelessWidget {
  static List<charts.Series<ChartData, String>> _createSampleData() {
    final data = [
      ChartData('Food Grown', 150),
      ChartData('Waste Saved', 80),
      ChartData('Money Saved', 200),
    ];

    return [
      charts.Series<ChartData, String>(
        id: 'Sustainability',
        colorFn: (_, __) => charts.MaterialPalette.green.shadeDefault,
        domainFn: (ChartData data, _) => data.label,
        measureFn: (ChartData data, _) => data.value,
        data: data,
      )
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: DashboardChart(
        seriesList: _createSampleData(),
        animate: true,
      ),
    );
  }
}
