import 'package:flutter/material.dart';
import '../models/tutorial.dart';
import '../widgets/tutorial_card.dart';

class TutorialsScreen extends StatelessWidget {
  final List<Tutorial> tutorials = [
    Tutorial(
      title: 'Growing Herbs on Your Balcony',
      description: 'Step-by-step guide to cultivate herbs in small spaces.',
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Tutorial(
      title: 'Rooftop Gardening Essentials',
      description: 'Maximize your rooftop space for sustainable farming.',
      imageUrl: 'https://via.placeholder.com/150',
    ),
    // Add more tutorials as needed
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: tutorials.length,
      itemBuilder: (context, index) {
        return TutorialCard(tutorial: tutorials[index]);
      },
    );
  }
}
