import 'package:flutter/material.dart';
import '../models/product.dart';

class ProductCard extends StatelessWidget {
  final Product product;

  const ProductCard({Key? key, required this.product}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Image.network(
            product.imageUrl,
            height: 100,
            width: double.infinity,
            fit: BoxFit.cover,
          ),
          ListTile(
            title: Text(product.name),
            subtitle: Text(product.description),
          ),
        ],
      ),
    );
  }
}
