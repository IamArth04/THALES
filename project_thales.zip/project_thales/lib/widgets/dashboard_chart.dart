// import 'package:flutter/material.dart';
// import 'package:charts_flutter/flutter.dart' as charts;

// class DashboardChart extends StatelessWidget {
//   final List<charts.Series> seriesList;
//   final bool animate;

//   const DashboardChart(
//       {Key? key, required this.seriesList, this.animate = false})
//       : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return charts.BarChart(
//       seriesList,
//       animate: animate,
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;

// Define the data model with a String x-axis label and a numeric value.
class ChartData {
  final String label;
  final int value;

  ChartData(this.label, this.value);
}

class DashboardChart extends StatelessWidget {
  final List<charts.Series<ChartData, String>> seriesList;
  final bool animate;

  const DashboardChart({
    Key? key,
    required this.seriesList,
    this.animate = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return charts.BarChart(
      seriesList,
      animate: animate,
    );
  }
}
