import 'package:flutter/material.dart';
import '../models/tutorial.dart';

class TutorialCard extends StatelessWidget {
  final Tutorial tutorial;

  const TutorialCard({Key? key, required this.tutorial}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: ListTile(
        leading: Image.network(
          tutorial.imageUrl,
          width: 50,
          height: 50,
          fit: BoxFit.cover,
        ),
        title: Text(tutorial.title),
        subtitle: Text(tutorial.description),
      ),
    );
  }
}
