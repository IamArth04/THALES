import 'package:flutter/material.dart';
import '../models/market.dart';

class MarketCard extends StatelessWidget {
  final Market market;

  const MarketCard({Key? key, required this.market}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: ListTile(
        leading: Icon(Icons.location_on, color: Colors.green),
        title: Text(market.name),
        subtitle: Text(market.location),
      ),
    );
  }
}
